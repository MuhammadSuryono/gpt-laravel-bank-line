<?php echo $__env->make('_partials._tag_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="login-page <?php echo e(env('APP_TYPE')); ?>">
		
			<?php if(env('APP_TYPE')!='bank'): ?>
				<?php echo $__env->make('_partials.header_login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php endif; ?>


		 	<?php echo $__env->yieldContent('content'); ?>
	 	
		
		 <?php if(env('APP_TYPE')=='bank'): ?>
		    <footer class="footer">
		        <?php echo $__env->make('_partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    </footer>
	    <?php endif; ?>
    

	<?php echo $__env->make('_partials._tag_script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>