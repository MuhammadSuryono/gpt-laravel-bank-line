<?php echo $__env->make('_partials._tag_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="hold-transition skin-black sidebar-mini <?php echo e(env('APP_TYPE')); ?>">
	
	<div id="vm">
		<div class="wrapper">
			 
		 	<?php echo $__env->make('_partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 	<?php echo $__env->make('_partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 	
		 	<div class="content-wrapper">
		 		
		 		<div id="preloader-content" v-cloak v-if="submit.process"><div class="preloader"></div></div>
		 		<div id="content-ajax">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
				<?php if(env('APP_TYPE')=='bank'): ?>
				    <footer class="footer relative">
				        <?php echo $__env->make('_partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				    </footer>
			    <?php endif; ?>
			</div>

	    </div>
		
		
	</div>
	

	<?php echo $__env->make('_partials._tag_script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>