<div class="page-content">
	<h1 class="page-title"> Ongoing Task</h1></hr>
	<div class="container-fluid">
		<h4>Host Error Mapping</h4>
		<div class="row">
			<table id="list" class="table table-striped table-bordered" border="2" cellpadding="2" style="border-collapse:collapse;">
				<thead>
				<tr>
					<th align="left"><strong>Created Date</strong></th>
					<th align="left"><strong>Feature</strong></th>
					<th align="left"><strong>Maker User Id</strong></th>
					<th align="left"><strong>Current Approval Level</strong></th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td align="left"></td>
					<td align="left"></td>
					<td align="left"></td>
					<td align="left"></td>
				</tr>
				</tbody>
			</table>
		</div>
		<div class="row">
			<div class="form-group">
				<div class="col-md-12">
					<button type="button" id="btn_refresh" name="btn_refresh" class="btn btn-default">REFRESH</button>
					<button type="button" id="btn_approve" name="btn_approve" class="btn btn-default">APPROVE</button>
					<button type="button" id="btn_reject" name="btn_reject" class="btn btn-default">REJECT</button>

				</div>
			</div>
		</div>

	</div>
</div>