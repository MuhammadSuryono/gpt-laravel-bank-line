<div id="nextUserModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Next User</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-xs-12">
						<table id="nextUserList" class="table table-bordered table-striped dataTable" border="2" cellpadding="2"
							   style="border-collapse:collapse;">
							<thead>
							<tr>
								<th><strong>User</strong></th>
								<th><strong>User Level</strong></th>
							</tr>
							</thead>
						</table>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->getFromJson('form.close'); ?></button>
			</div>
		</div>

	</div>
</div>