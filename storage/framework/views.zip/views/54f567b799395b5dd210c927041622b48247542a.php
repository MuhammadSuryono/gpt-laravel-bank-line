<?php echo $__env->make('_partials.header_content',['breadcrumb'=>['Transaction Update Listing','detail']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div id="notification"></div>
            <input type="hidden" id="pendingTaskId" value=""/>
            <input type="hidden" id="refNo" value=""/>
            <input type="hidden" id="menuCode" value=""/>
            <div class="box">
                
                
            <div class="box-header">
                <h3 class="box-title">Transaction Detail</h3><br>
            </div>
            <form class="form-horizontal">
                <div class="box-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="form-group">
                                <label class="col-md-5 control-label">Menu</label>
                                <div class="col-md-6">
                                    <label id="menuName">-</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <label class="col-md-5 control-label">Transaction Status</label>
                                <div class="col-md-6">
                                    <label id="trxStatus">-</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <label class="col-md-5 control-label">Transaction Reference Number</label>
                                <div class="col-md-6">
                                    <label id="trxRefNo">-</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-header">
                    <h3 class="box-title">Transaction Activity</h3><br>
                </div>
                <div class="box-body">
                    <div class="container-fluid">
                        <div class="table-hidden">
                            <div class="form-group">
                                <table id="activityList" class="table table-bordered table-striped dataTable" border="2" cellpadding="2"
                                       style="border-collapse:collapse;">
                                    <thead>
                                    <tr>
                                        <th align="center" ><strong>Activity Date</strong></th>
                                        <th align="center" ><strong>Activity</strong></th>
                                        <th align="center" ><strong>Activity By</strong></th>
                                        <th align="center" ><strong>Approval Count</strong></th>
                                        <th align="center" ><strong>Amount</strong></th>
                                        <th align="center" ><strong>Transaction Status</strong></th>
                                        <th align="center" ><strong></strong></th>
                                    </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="actvDetail" style="display:none">
                    <div class="box-header">
                        <h3 class="box-title">Transaction Activity Detail</h3><br>
                    </div>
                    <form class="form-horizontal formDetailInclude">
                        <div class="box-body" id="detailActivity">
                            
                        </div>
                        <div class="box-body" id="detailExecuted">
                            
                        </div>
                    </form>
                    
                </div>
                <div class="box-footer">
                    <div class="state_view">
                        <div class="float-left">
                            <button type="button" id="back" name="back" class="btn btn-default back"><?php echo app('translator')->getFromJson('form.back'); ?></button>
                            <button type="button" id="save_screen" name="save_screen" class="btn btn-default" style="display:none" onclick="save_pdf();"><?php echo app('translator')->getFromJson('form.save_pdf'); ?></button>
                        </div>
                        <div class="float-right">
                            <button type="button" id="update_success" name="update_success" class="btn btn-default" onclick="updateTransactionAction('SUCCESS');">Update Sucess</button>
                            <button type="button" id="update_failed" name="update_failed" class="btn btn-default" onclick="updateTransactionAction('FAILED');">Update Failed</button>
                            <button type="button" id="next_user" name="next_user" class="btn btn-info"><?php echo app('translator')->getFromJson('form.next_user'); ?></button>
                            <button type="button" id="done" name="done" class="btn btn-default" onclick="backAction();">Done</button>
                            
                        </div>     
                    </div>
                </div>
                <?php echo $__env->make('_partials.next_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </form>

            </div>
        </div>
    </div>

</section>

<script>
    var activityList;
    var service = '<?php echo e($service); ?>';
    var noRef;
    var updateStatus;
    $(document).ready(function () {

        $('#done').hide();
        $('#back').show();
        $('#update_success').show();
        $('#update_failed').show();
        $('#save_screen').hide();
        $('#next_user').hide();

        activityList = $('#activityList').DataTable({
            "paging" : false,
            "ordering" : false,
            "info": false,
            "destroy": true,
            "searching": false,
            "autoWidth":false,
            "columnDefs": [
               {
                    sortable: false,
                    width: "15.83%",
                    targets: 0,
               },
               {
                    targets: 1,
                    sortable: false,
                    width: "15.83%"
                },
                {
                    targets: 2,
                    sortable: false,
                    width: "15.83%"
                },
                {
                    targets: 3,
                    sortable: false,
                    className: 'dt-center',
                    width: "15.83%"
                },
                {
                    targets: 4,
                    sortable: false,
                    width: "15.83%"
                },
                {
                    targets: 5,
                    sortable: false,
                    width: "15.83%"
                },
                {
                    targets: 6,
                    sortable: false,
                    className: 'dt-center',
                    width: "5%"
                }

            ]
        });


        $('.back').on('click', function () {
           var res = app.setView(service,'landing');
        });

         $('.done').on('click', function () {
           var res = app.setView(service,'landing');
        });

    });

    function getDetail(){

        var pendingTaskId= $('#pendingTaskId').val();
        var url_action= 'detailTransactionStatus';
        var value ={
            pendingTaskId: pendingTaskId,
        };
        $.ajax({
            url: 'getAPIData',
            method: 'post',
            data:{
                value:value,
                menu:service,
                action:'DETAIL',
                url_action:url_action
            },
            success: function (data) {

                var result = JSON.parse(data);
                if (result.status=="200") {

                    $.each(result.activities, function (idx, obj) {
                            activityList.row.add([
                                obj.activityDate,
                                obj.activity,
                                obj.userId +' - '+ obj.userName,
                                obj.approvalLvCount != '' ? (obj.approvalLvCount +' of '+obj.approvalLvRequired) : '-',
                                obj.amount !='-1' ? (obj.amountCcyCd +' '+currencyFormat(obj.amount)) : '',
                                obj.status,
                                (obj.isCreate == 'Y' ? '<button type="button" id="btnView" name="btnView" class="btn btn-info viewBtn" onclick="viewDetai()">View</button>' : '')||(obj.isExecute == 'Y' ? '<button type="button" id="btnExct" name="btnExct" class="btn btn-info" onclick="viewDetaiExecuted(\''+obj.executedId+'\')">View</button>' : '')
                            ]).draw(false);
                        });

                } else {
                    flash('warning', result.message);
                }



            }, error: function (xhr, ajaxOptions, thrownError) {
                var msg = '<?php echo e(trans('form.conn_error')); ?>';
                flash('warning', msg);
                console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
            },
            complete: function(data) {
                $('.table-hidden').show();

                var menuCode = $('#menuCode').val();

                $.ajax({
                        url: 'getTrxStatusDetailView',
                        method: 'post',
                        data:{
                            value:menuCode,
                            service:service,
                        },
                        success: function (data) {
                            $('#detailActivity').html(data);
                        }

                });

            }
        });
    }


    function backAction(status){
        var res = app.setView(service,'landing');
    }

    function updateTransactionAction(status){
        updateStatus = status;
        $.confirm({
            title: '<?php echo e(trans('form.submit')); ?>',
            content: 'Confirm Update Transaction Status?',
            buttons: {

                cancel: {
                    text: '<?php echo e(trans('form.cancel')); ?>',
                    btnClass: 'btn-default',
                    action: function(){
                        $('#confirm').prop('disabled',false);
                    }
                },
                confirm: {
                    text: '<?php echo e(trans('form.confirm')); ?>',
                    btnClass: 'btn-primary',
                    action: function(){
                        updateTransactionSubmit(status);
                    }
                }
            }
        });
    }

    function updateTransactionSubmit(status){
        var url_action = 'submit';
        var action = 'UPDATE_STATUS';

        var value = {
            "pendingTaskId": $('#pendingTaskId').val(),
            "referenceNo": $('#refNo').val(),
            "executedMenuCode": $('#menuCode').val(),
            "status":status,
            "menuName": $('#menuName').text(),
            "trxStatus": $('#trxStatus').text(),
            "trxRefNo":$('#trxRefNo').text(),
            "corporateId":"corpID",
            "name":"name"
        };
        $.ajax({
            url: 'getAPIData',
            method: 'post',
            data: {"_token": "<?php echo e(csrf_token()); ?>", action:action,url_action:url_action,menu: service, value: value},
            success: function (data) {
                $('#confirm').prop('disabled',false);

                var result = JSON.parse(data);
                if (result.status=="200") {
                    noRef=result.referenceNo;
                    flash('success', result.message+'<br>'+'ReferenceNo: '+ result.referenceNo+'<br>'+result.dateTimeInfo);
                    $('#done').show();
                    $('#update_success').hide();
                    $('#update_failed').hide();
                    $('#back').hide();
                    $('#save_screen').show();
                    $('#next_user').show();

                } else {
                    flash('warning',result.message);
                }
            }, error: function (xhr, ajaxOptions, thrownError) {
                //$('#confirm').prop('disabled',false);
                flash('warning', 'Form Submit Failed');
                console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
            }
        });

    }

    function viewDetai(){

        $('.actvDetail').show();
        $('#detailActivity').show();
        $('#detailExecuted').hide();

         getDetailData($('#refNo').val());
    }

    function viewDetaiExecuted(id) {

        var menuCode = $('#menuCode').val();
        // console.log("masuk viewDetaiExecuted", id + " " + menuCode);

        $('.actvDetail').show();
        $('#detailExecuted').show();
        $('#detailActivity').hide();

        $.ajax({
                url: 'getTrxStatusDetailView',
                method: 'post',
                data:{
                    value:'EXECUTE',
                    service:service,
                },
                success: function (data) {
                    $('#detailExecuted').html(data);
                    getDetailExecuted(id, menuCode);
                }

        });

    }


    function currencyFormat (num) {
        return parseFloat(num).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");  //<--- $1  is a special replacement pattern which holds a value of the first parenthesised submatch string 
    }


</script>