<div class="page-content">
	<h1 class="page-title"> Host Error Mapping</h1></hr>
	<div class="container-fluid">
		<h4>Host Error Mapping</h4>
		<div class="row">
			<div class="form-group">
				<label class="col-md-2">Code</label>
				<div class="col-md-6">
					<input type="text" id="code" name="code" class="form-control">

				</div>
			</div>
		</div>
		<div class="row">
			<div class="form-group">
				<label class="col-md-2">Name in English</label>
				<div class="col-md-6">
					<input type="text" id="name_in_english" name="name_in_english" class="form-control">

				</div>
			</div>
		</div>
		<div class="row">
			<div class="form-group">
				<label class="col-md-2">Name in Indonesia</label>
				<div class="col-md-6">
					<input type="text" id="name_in_indonesia" name="name_in_indonesia" class="form-control">

				</div>
			</div>
		</div>
		<div class="row">
			<div class="form-group">
				<label class="col-md-2"></label>
				<div class="col-md-6">
					<button type="button" id="search" name="search" class="btn btn-default">SEARCH</button>
					<button type="button" id="add" name="add" class="btn btn-default">ADD</button>

				</div>
			</div>
		</div>
		<h4>Host Error Mapping Listing</h4>
		<div class="row">
			<table id="list" class="table table-striped table-bordered" border="2" cellpadding="2" style="border-collapse:collapse;">
				<thead>
				<tr>
					<th align="center"><strong>Code</strong></th>
					<th align="center"><strong>Name in English</strong></th>
					<th align="center"><strong>Name in Indonesia</strong></th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td align="left"></td>
					<td align="left"></td>
					<td align="left"></td>
				</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>