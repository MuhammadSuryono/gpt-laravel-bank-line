<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Limit Setup
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#" class="back"><i class="fa fa-dashboard"></i> Limit Setup</a></li>
        <li class="active">Limit Setup Add</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div id="notification"></div>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Limit Setup Add</h3>
                    <span id="preview" class="state_view" style="color:darkred"><small><i>Preview</i></small></span>
                </div>
                <form class="form-horizontal">
                <div class="box-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="form-group">
                                <label class="col-md-2 control-label">Limit Setup Code</label>
                                <div class="col-md-6">
                                    <input type="text" id="code" name="code" class="form-control state_edit" autocomplete="off" value="">
                                    <span id="code_view" class="col-md-2 state_view">-</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <label class="col-md-2 control-label">Limit Setup Name</label>

                                <div class="col-md-6">
                                    <input type="text" id="name" name="name" class="form-control state_edit" autocomplete="off" value="">
                                    <span id="name_view" class="col-md-2 state_view">-</span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                    <div class="box-header">
                        <h3 class="box-title table-hidden">Limit Setup Listing</h3>
                    </div>
                    <div class="container-fluid">
                        <div class="box-body">
                           <div class="row table-hidden">
                               <div class="form-group">
                                <table id="list" class="table table-bordered table-striped dataTable" border="2" cellpadding="2"
                                       style="border-collapse:collapse;">
                                    <thead>
                                    <tr>
                                        <th rowspan="2"></th>
                                        <th align="center" rowspan="2"><strong>Service</strong></th>
                                        <th align="center" rowspan="2"><strong>Currency matrix</strong></th>
                                        <th align="center" rowspan="2"><strong>Max. No. Of Transaction / Day</strong></th>
                                        <th align="center" colspan="2"><strong>Maximum Transaction Amount / Day</strong></th>

                                    </tr>
                                    <tr>
                                        <th align="center"><strong>Currency</strong></th>
                                        <th align="center"><strong>Value</strong></th>
                                    </tr>
                                    </thead>

                                </table>
                               </div>
                           </div>
                            <div class="row table-hidden">
                                    <div class="form-group">
                                           <label class="col-md-2"></label>
                                           <div class="col-md-6 state_edit">
                                               <button type="button" id="confirm" name="confirm" class="btn btn-default"><?php echo app('translator')->getFromJson('form.confirm'); ?></button>
                                               <button type="button" id="back" name="back" class="btn btn-default back"><?php echo app('translator')->getFromJson('form.back'); ?></button>
                                           </div>
                                            <div class="col-md-6 state_view">
                                                <button type="button" id="submit_view" name="submit_view" class="btn btn-danger"><?php echo app('translator')->getFromJson('form.submit'); ?></button>
                                                <button type="button" id="back_view" name="back_view" class="btn btn-default"><?php echo app('translator')->getFromJson('form.back'); ?></button>
                                            </div>
                                       </div>
                            </div>



                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

</section>

<script>
    var oTable;
    var currencyOption;
    $(document).ready(function () {

        stateEdit();
        $('.table-hidden').hide();
        var id = 'MNU_GPCASH_PRO_LMT_PC';
        var submit_data;
        getCurrency();

        oTable = $('#list').DataTable({
            "paging" : false,
            "ordering" : false,
            "info": false,
            "destroy": true,
            "select": false,
            "searching": false,
            "autoWidth":false,
            "lengthMenu": [[10, 25, 50], [10, 25, 50]],
            "columnDefs": [
                {
                    sortable: false,
                    width: "5px",
                    targets: 0
                },
                {
                    targets: 1,
                    sortable: false,
                    width: "250px"
                },
                {
                    targets: 2,
                    sortable: false,
                    width: "100px"
                },
                {
                    targets: 3,
                    sortable: false,
                    width: "50px"
                },
                {
                    targets: 4,
                    sortable: false,
                    width: "30px"
                },
                {
                    targets: 5,
                    sortable: false,
                    width: "100px"
                }

            ]
        });

        $('#submit_view').on('click', function () {


            var value = {
                "code":$('#code').val(),
                "name":$('#name').val(),
                "transactionLimitList":submit_data
            };
            $.ajax({
                url: 'add',
                method: 'post',
                data: {"_token": "<?php echo e(csrf_token()); ?>",menu:id,value:value},
                success: function (data) {
                    result = JSON.parse(data);
                    if(result.hasOwnProperty("referenceNo")){
                        flash('success','ReferenceNo: '+result.referenceNo);
                        $('#submit_view').hide();
                        $('#preview').text(result.referenceNo);
                        stateSuccess();
                    }else{
                        flash('warning','Form Submit Failed');
                    }

                }, error: function (xhr, ajaxOptions, thrownError) {
                    flash('warning','Form Submit Failed');
                    console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
                }
            });

        });


        $('#confirm').on('click', function () {
            submit_data = getTableData();
            stateView();
        });

        $('#back_view').on('click', function () {
            stateEdit();
        });

        $('.back').on('click', function () {
            $.ajax({
                url: 'getView/'+id,
                method: 'post',
                success: function (data) {
                    $(window).scrollTop(0);
                    $('.content-wrapper').html(data);


                }, error: function (xhr, ajaxOptions, thrownError) {
                    console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
                }
            });
        });

    });

    function getMatrix(){
        $.ajax({
            url: 'getLimitSetupMatrix',
            method: 'post',
            success: function (data) {

               var result = JSON.parse(data);
                $.each(result, function (i) {
                    $.each(result[i], function (idx, obj) {
                            oTable.row.add([
                            '<input id="check" name="check" class="form-check-input state_edit" value="" type="checkbox">',
                            obj.serviceName+'<input id="service_code" name="service_code" class="form-control state_edit" value="'+obj.serviceCode+'" type="hidden">',
                            obj.currencyMatrixName+'<input id="matrix_id" name="matrix_id" class="form-control state_edit" value="'+obj.serviceCurrencyMatrixId+'" type="hidden">',
                            '<input id="num_trans" name="num_trans" class="form-control state_edit" value="" type="text" style="width:100%;"><span id="num_trans_view" class="state_view">-</span>',
                            currencyOption+'<span id="currCode_view" class="state_view">-</span>',
                            '<input id="max_trans" name="max_trans" class="form-control state_edit" value="" type="text" style="width:100%;"><span id="max_trans_view" class="state_view">-</span>'
                        ]).draw(false);
                    });
                });
                stateEdit();

            }, error: function (xhr, ajaxOptions, thrownError) {
                console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
            },
            complete: function(data) {
                $('.table-hidden').show();

            }
        });
    }

    function getCurrency(){
        $.ajax({
            url: 'getLimitSetupCurrencyCode',
            method: 'post',
            success: function (data) {
                var result = JSON.parse(data);
                currencyOption = '<select id="currCode" class="form-control state_edit">';
                $.each(result, function (idx, obj) {
                    if(obj.code=="IDR") {
                        currencyOption += '<option value="' + obj.code + '" selected="selected">' + obj.code + '</option>';
                    }else{
                        currencyOption += '<option value="' + obj.code + '">' + obj.code + '</option>';
                    }
                });
                currencyOption += '</select>';


            }, error: function (xhr, ajaxOptions, thrownError) {
                console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
            },complete: function(data) {
                getMatrix();
            }
        });
    }

    function getTableData(){
        var data = [];

        $("#list").find("tbody tr").each(function(){
            var check = ($('td:eq(0)', $(this)).children().is(':checked') ? 1:0);
            if(check==0){
                $('td:eq(0)', $(this)).parent().hide();
            }
            var service_code = $('td:eq(1)', $(this)).find('#service_code').val();
            var matrix_id = $('td:eq(2)', $(this)).find('#matrix_id').val();
            var num_trans = $('td:eq(3)', $(this)).find('#num_trans').val();
            $('td:eq(3)', $(this)).find('#num_trans_view').text(num_trans);
            var curr_code = $('td:eq(4)', $(this)).find('#currCode').val();
            $('td:eq(4)', $(this)).find('#currCode_view').text(curr_code);
            var max_trans = $('td:eq(5)', $(this)).find('#max_trans').val();
            $('td:eq(5)', $(this)).find('#max_trans_view').text(max_trans);

            var obj = {serviceCode:service_code,serviceCurrencyMatrixId:matrix_id,maxTrxPerDay:num_trans,currencyCode:curr_code,maxTrxAmountPerDay:max_trans};
            if(check==1) {
                data.push(obj);
            }
        });
        return data;
    }

    function stateEdit(){
        $('.state_view').hide();
        $('.state_edit').show();
        $("#list").find("tbody tr").each(function(){

                $('td:eq(0)', $(this)).parent().show();

        });
    }

    function stateView(){


        var code = ($('#code').val()==''?'-':$('#code').val());
        var name = ($('#name').val()==''?'-':$('#name').val());

        $('#preview').text('Preview');
        $('.state_edit').hide();
        $('.state_view').show();
        $('#code_view').text(code);
        $('#name_view').text(name);


    }

    function stateSuccess(){
        $('#code_1').val('');
        $('#name').val('');
        $('input.state_edit').val('');
        $('span.state_view').val('-');
    }

</script>