<div class="text-center">
	Copyright © gpt. All Rights Reserved.
</div>