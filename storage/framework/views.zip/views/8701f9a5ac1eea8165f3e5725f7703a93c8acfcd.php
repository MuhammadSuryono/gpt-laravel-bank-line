<?php echo $__env->make('_partials.header_content',['breadcrumb'=>['authentication device','detail']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div id="notification"></div>
            <input type="hidden" id="code" value=""/>
            <input type="hidden" id="name" value=""/>
            <div class="box">
                
                
                <div class="box-header">
                    <h3 class="box-title">Corporate Detail</h3><br>
                </div>
                <form class="form-horizontal">
                <div class="box-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="form-group">
                                <label class="col-md-2 control-label">Corporate</label>
                                <div class="col-md-6">
                                    <label id="code_1">-</label>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                </form>
                    <div class="box-header">
                        <h3 class="box-title table-hidden">Device Listing</h3>
                    </div>
                    
                    <div class="box-body">
                       
                            <table id="list" class="table table-bordered table-striped dataTable" border="2" cellpadding="2"
                                   style="border-collapse:collapse;">
                                <thead>
                                <tr>

                                    <th align="left"><strong>Serial Number</strong></th>
                                    <th align="left"><strong>Assigned To</strong></th>
                                    <th align="left"><strong>Assigned By</strong></th>
                                    <th align="left"><strong>Assigned Date</strong></th>
                                    <th align="left"><strong>Status</strong></th>
                                    <th align="left" colspan="3"><strong></strong></th>
                                </tr>
                                </thead>
                            </table>
                           
                    </div>
                    

                    <div class="box-footer">
                           <div class="state_view">
                                   <div class="float-left">
                                       
                                       <button type="button" id="back" name="back" class="btn btn-default back"><?php echo app('translator')->getFromJson('form.back'); ?></button>
                                   </div>
                                   <div class="float-right">

                                   </div>
                           </div>
                       </div>
            </div>
        </div>
    </div>

</section>
<div id="unlockModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Unlock Authentication Device</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-xs-12">
                        <div id="alerts">

                        </div>
                        <form id="form-area" class="form-horizontal form-area">
                            <input type="hidden" id="code_edit" value=""/>
                            <div class="box-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Serial Number</label>
                                            <div class="col-md-8">
                                                <label id="tokenNo-modal" class="state_view">-</label>
                                                <input type="hidden" id="userId-modal">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group">
                                            <label class="col-md-4 control-label"><strong>Token Challenge Code*</strong></label>
                                            <div class="col-md-8">
                                                <input type="text" id="randomLockedCode" name="randomLockedCode" class="form-control" autocomplete="off" value="" maxlength="20" data-error="This field is required." required>
                                                <div class="help-block with-errors"></div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="cancel" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->getFromJson('form.cancel'); ?></button>
                <button type="button" id="confirm" name="confirm" class="btn btn-primary"><?php echo app('translator')->getFromJson('form.submit'); ?></button>
            </div>
        </div>

    </div>
</div>
<script>
    var oTable;
    var id = '<?php echo e($service); ?>';
    $(document).ready(function () {
        $('.table-hidden').hide();
        $('.state_delete').hide();

        oTable = $('#list').DataTable({
            //"paging" : false,
            "ordering" : false,
            "info": false,
            "destroy": true,

            "searching": false,
            "autoWidth":false,
            "lengthMenu": [[10, 25, 50], [10, 25, 50]],
            "columnDefs": [

                {
                    targets: 0,
                    sortable: true,
                    width: "12%"
                },
                {
                    targets: 1,
                    sortable: true,
                    width: "20%"
                },
                {
                    targets: 2,
                    sortable: true,
                    width: "18%"
                },
                {
                    targets: 3,
                    sortable: true,
                    width: "15%"
                },
                {
                    targets: 4,
                    sortable: false,
                    width: "10%"
                },
                {
                    targets: 5,
                    sortable: true,
                    width: "5%"
                },
                {
                    targets: 6,
                    sortable: true,
                    width: "5%"
                },
                {
                    targets: 7,
                    sortable: true,
                    width: "5%"
                }
            ],
            "dom": "lfBrtip",
            "buttons": [{
                text: 'Add Device',
                action: function ( e, dt, node, config ) {
                    var code = $('#code').val();
                    var name = $('#name').val();
                    var corporate = $('#code_1').text();
                    var res = app.setView(id,'add');
                    if(res=='done'){
                        $('#type').val('add');
                        $('#code_edit').val(code);
                        $('#name').val(name);
                        $('#code_1').text(corporate);
                    }
                    
                }
            }]
        });


        $('#edit').on('click', function () {
            var code = $('#code').val();
            var corporate = $('#code_1').text();
            var cifid = $('#cifid').text();
            var name = $('#name').val();
            var res = app.setView(id,'add');
            if(res=='done'){
                $('#code').val(code);
                $('#code_1').text(corporate);
                $('#cifid').text(cifid);
                $('#type').val('edit');
                $('#name').val(name);
                getData(submit_data);
            }
            
        });

        $('#confirm').on('click', function () {
            $('#form-area').validator('validate');
            if($('#form-area').validator('validate').has('.has-error').length!=0){
                return;
            }

            $(this).prop('disabled',true);

            $.confirm({
                title: '<?php echo e(trans('form.submit')); ?>',
                content: 'Confirm Unlock Serial Number?',
                buttons: {

                    cancel: {
                        text: '<?php echo e(trans('form.cancel')); ?>',
                        btnClass: 'btn-default',
                        action: function(){
                            $('#confirm').prop('disabled',false);
                        }
                    },
                    confirm: {
                        text: '<?php echo e(trans('form.confirm')); ?>',
                        btnClass: 'btn-primary',
                        action: function(){
                            unlockSubmit();
                        }
                    }
                }
            });


        });



        $('.back').on('click', function () {
            var res = app.setView(id,'landing');
        });
        $('div.dt-buttons').css('float','right');
        $('a.dt-button').addClass('btn btn-primary');


    });

    function unblockAction(e){
        $.confirm({
            title: '<?php echo e(trans('form.submit')); ?>',
            content: 'Confirm Unblock Serial Number?',
            buttons: {

                cancel: {
                    text: '<?php echo e(trans('form.cancel')); ?>',
                    btnClass: 'btn-default',
                    action: function(){
                        $('#confirm').prop('disabled',false);
                    }
                },
                confirm: {
                    text: '<?php echo e(trans('form.confirm')); ?>',
                    btnClass: 'btn-primary',
                    action: function(){
                        unblockSubmit(e);
                    }
                }
            }
        });
    }

    function unblockSubmit(e){
        var url_action = 'unblockToken';
        var action = 'UNBLOCK';

        var value = {
            "userId": $(e).attr('data-userid'),
            "corporateId": $('#code').val(),
            "tokenNo": $(e).attr('data-tokenNo')

        };
        $.ajax({
            url: 'getAPIData',
            method: 'post',
            data: {"_token": "<?php echo e(csrf_token()); ?>", action:action,url_action:url_action,menu: id, value: value},
            success: function (data) {
                $('#confirm').prop('disabled',false);
                //console.log(data);
                //return;
                var result = JSON.parse(data);
                if (result.status=="200") {
                    flash('success',result.message);
                    //$('#unlockModal').modal('hide');
                    //stateSuccess();
                } else {
                    //$('#submit_view').prop('disabled',false);

                    flash('warning',result.message);
                }

            }, error: function (xhr, ajaxOptions, thrownError) {
                //$('#confirm').prop('disabled',false);
                flash('warning', 'Form Submit Failed');
                console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
            }
        });

    }

    function unlockSubmit(){
        var url_action = 'unlockToken';
        var action = 'UNLOCK';


        var value = {

            "userId": $('#userId-modal').val(),
            "corporateId": $('#code').val(),
            "tokenNo": $('#tokenNo-modal').text(),
            "randomLockedCode": $('#randomLockedCode').val()
        };
        $.ajax({
            url: 'getAPIData',
            method: 'post',
            data: {"_token": "<?php echo e(csrf_token()); ?>", action:action,url_action:url_action,menu: id, value: value},
            success: function (data) {
                $('#confirm').prop('disabled',false);
                //console.log(data);
                //return;
                var result = JSON.parse(data);
                if (result.status=="200") {
                    flash('success',result.message);
                    $('#unlockModal').modal('hide');
                    //stateSuccess();
                } else {
                    //$('#submit_view').prop('disabled',false);

                    flash('warning',result.message);
                }

            }, error: function (xhr, ajaxOptions, thrownError) {
                //$('#confirm').prop('disabled',false);
                flash('warning', 'Form Submit Failed');
                console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
            }
        });

    }

    function unassignAction(e){
        $.confirm({
            title: '<?php echo e(trans('form.submit')); ?>',
            content: 'Confirm Unassign Serial Number?',
            buttons: {

                cancel: {
                    text: '<?php echo e(trans('form.cancel')); ?>',
                    btnClass: 'btn-default',
                    action: function(){
                        $('#confirm').prop('disabled',false);
                    }
                },
                confirm: {
                    text: '<?php echo e(trans('form.confirm')); ?>',
                    btnClass: 'btn-primary',
                    action: function(){
                        unassignSubmit(e);
                    }
                }
            }
        });
    }

    function unassignSubmit(e){
        var url_action = 'unassignToken';
        var action = 'UNASSIGN';

        var value = {
            "userId": $(e).attr('data-userid'),
            "userName": $(e).attr('data-userName'),
            "assignedBy": $(e).attr('data-assignedBy'),
            "assignedDate": $(e).attr('data-assignedDate'),
            "status": $(e).attr('data-status'),
            "corporateId": $('#code').val(),
            "name": $('#name').val(),
            "tokenNo": $(e).attr('data-tokenNo')

        };
        $.ajax({
            url: 'getAPIData',
            method: 'post',
            data: {"_token": "<?php echo e(csrf_token()); ?>", action:action,url_action:url_action,menu: id, value: value},
            success: function (data) {
                $('#confirm').prop('disabled',false);
                //console.log(data);
                //return;
                var result = JSON.parse(data);
                if (result.status=="200") {
                    flash('success',result.message);
                    //$('#unlockModal').modal('hide');
                    //stateSuccess();
                } else {
                    //$('#submit_view').prop('disabled',false);

                    flash('warning',result.message);
                }

            }, error: function (xhr, ajaxOptions, thrownError) {
                //$('#confirm').prop('disabled',false);
                flash('warning', 'Form Submit Failed');
                console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
            }
        });

    }

    function accountNoDetail(accountNo){
        getAccountDetail(accountNo);
    }

    function getData(code,name){
        var value = {
            corporateId: code,
            currentPage: "1",
            pageSize: "20",
            orderBy: {"tokenNo": "ASC"}
        };
        var url_action = 'search';
        var action = 'DETAIL';
        var menu = id;
        $.ajax({
            url: 'getAPIData',
            method: 'post',
            data: {
                value : value,
                menu : menu,
                url_action : url_action,
                action : action,
                _token : '<?php echo e(csrf_token()); ?>'
            },
            success: function (data) {

                var result = JSON.parse(data);
                if (result.status=="200") {
                    var detail = result.result;
                    $('#code_1').text(code+' - '+name);
                    $('#name').val(name);
                    oTable.clear();

                    $.each(detail, function (idx, obj){
                        var disabled_unblock = '';
                        var color_unblock = 'blue';
                        var disabled_unlock = '';
                        var color_unlock = 'blue';
                        var disabled_unassign = '';
                        var color_unassign= 'red';
                        if(obj.status=='Active'){
                            disabled_unblock = 'disabled';
                            color_unblock = 'gray';
                        }
                        if(obj.userName==""&&obj.userId==""){
                            disabled_unblock = 'disabled';
                            color_unblock = 'gray';
                            disabled_unlock = 'disabled';
                            color_unlock = 'gray';
                            disabled_unassign = 'disabled';
                            color_unassign = 'gray';
                        }
                        //console.log(obj);
                        oTable.row.add([
                            obj.tokenNo+'<input type=hidden id="tokenNo" value="'+obj.tokenNo+'">',
                            obj.userId+' - '+obj.userName+'<input type=hidden id="userId" value="'+obj.userId+'">'+'<input type=hidden id="userName" value="'+obj.userName+'">',
                            obj.assignedBy+'<input type=hidden id="assignedBy" value="'+obj.assignedBy+'">',
                            obj.assignedDate+'<input type=hidden id="assignedDate" value="'+obj.assignedDate+'">',
                            obj.status+'<input type=hidden id="status" value="'+obj.status+'">',
                            '<button type="button" class="unblock btn btn-default" data-tokenNo="'+obj.tokenNo+'" data-userId="'+obj.userId+'" style="border-color:'+color_unblock+';" onClick="unblockAction(this);" '+disabled_unblock+'><span style="color:'+color_unblock+';">Unblock</span></button>',
                            '<button type="button" class="unlock btn btn-default" data-tokenNo="'+obj.tokenNo+'" data-userId="'+obj.userId+'" style="border-color:'+color_unlock+';" onClick="unlockAction(this);" '+disabled_unlock+'><span style="color:'+color_unlock+';">Unlock</span></button>',
                            '<button type="button" class="unassign btn btn-default" data-tokenNo="'+obj.tokenNo+'" data-userId="'+obj.userId+'" data-userName="'+obj.userName+'" data-assignedBy="'+obj.assignedBy+'" data-assignedDate="'+obj.assignedDate+'" data-status="'+obj.status+'" style="border-color:'+color_unassign+';" onClick="unassignAction(this);" '+disabled_unassign+'><span style="color:'+color_unassign+';">Unassign</span></button>'
                        ]).draw(true);
                    });
                } else {
                    flash('warning', result.message);
                }



            }, error: function (xhr, ajaxOptions, thrownError) {
                var msg = '<?php echo e(trans('form.conn_error')); ?>';
                flash('warning', msg);
                console.log(xhr.status + " ," + " " + ajaxOptions + ", " + thrownError);
            },
            complete: function(data) {
                $('.table-hidden').show();

            }
        });
    }


    function getTableData() {
        var data = [];

        $("#list").find("tbody tr").each(function () {
            var check = ($('td:eq(0)', $(this)).children().is(':checked') ? 1 : 0);
            if (check == 0) {
                $('td:eq(0)', $(this)).parent().hide();
            }
            var tokenNo = $('td:eq(1)', $(this)).find('#tokenNo').val();
            var userId = $('td:eq(2)', $(this)).find('#userId').val();
            var assignedBy = $('td:eq(3)', $(this)).find('#assignedBy').val();
            var assignedDate = $('td:eq(4)', $(this)).find('#assignedDate').val();
            var status = $('td:eq(5)', $(this)).find('#status').val();
            var retry = $('td:eq(6)', $(this)).find('#retry').val();

            var obj = {
                tokenNo: tokenNo,
                userId: userId,
                assignedBy:assignedBy,
                assignedDate:assignedDate,
                status:status,
                retry:retry
            };
            if (check == 1) {
                data.push(obj);
            }
        });
        return data;
    }

    function countChecked(){
        var checked = 0;
        $("#list").find("tbody tr").each(function () {
            ($('td:eq(0)', $(this)).children().is(':checked') ? checked++ :'');
        });

        return checked;
    }

    function unlockAction(e){

        $('#unlockModal').modal('show');
        $('#tokenNo-modal').text($(e).attr('data-tokenNo'));
        $('#userId-modal').val($(e).attr('data-userid'));
    }


</script>